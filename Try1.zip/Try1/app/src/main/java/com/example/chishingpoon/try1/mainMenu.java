/*



 */



package com.example.chishingpoon.try1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;


public class mainMenu extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        /*
        final TextView roomOne = findViewById(R.id.roomOne);

        roomOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mainMenu.this, Menu.class));
                roomOne.setText(Menu.room);
                //Intent intent = getIntent();
                //roomOne.setText(intent.getStringExtra("room"));
            }
        });


        final TextView roomTwo = findViewById(R.id.roomTwo);
        roomTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                roomTwo.setText(intent.getStringExtra("room"));
            }
        });
        */


    }

}